package com.example.transactiondetails;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

import static com.example.transactiondetails.R.id.transactionDate;

public class MsgAdapter extends RecyclerView.Adapter<MsgAdapter.ViewHolder> {

    public Context context;
    public ArrayList<MessageData> dataList;

    public MsgAdapter(Context context, ArrayList<MessageData> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = LayoutInflater.from(viewGroup.getContext());
        View listItem = layoutInflater.inflate(R.layout.transaction_list, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        MessageData data = dataList.get(i);
        if (data.getDebitAmount() == null) {
            viewHolder.debitLayout.setVisibility(View.INVISIBLE);
            viewHolder.creditdata.setText(data.getCreditAmount());
        }
        if (data.getCreditAmount() == null) {
            viewHolder.creditLayout.setVisibility(View.INVISIBLE);
            viewHolder.debitdata.setText(data.getDebitAmount());
        }
        viewHolder.debitdata.setText(data.getDebitAmount());
        viewHolder.tdate.setText(data.getDate());
        viewHolder.balance.setText(data.getBalance());
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView debitdata;
        public LinearLayout debitLayout, creditLayout;
        public TextView creditdata;
        public TextView tdate;
        public TextView balance;


        public ViewHolder(View itemView) {
            super(itemView);
            this.creditLayout = itemView.findViewById(R.id.creditLayout);
            this.debitLayout = itemView.findViewById(R.id.debitLayout);
            this.creditdata = itemView.findViewById(R.id.creditAmount);
            this.debitdata = itemView.findViewById(R.id.debitAmount);
            this.tdate = itemView.findViewById(R.id.transactionDate);
            this.balance = itemView.findViewById(R.id.balanceAmount);
        }
    }
}

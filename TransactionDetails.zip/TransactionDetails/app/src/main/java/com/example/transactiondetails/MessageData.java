package com.example.transactiondetails;

public class MessageData {

    private String debitAmount;
    private String creditAmount;
    private String date;
    private String balance;

    public MessageData(String debitAmount, String creditAmount, String date, String balance) {
        this.debitAmount = debitAmount;
        this.date = date;
        this.creditAmount = creditAmount;
        this.balance = balance;
    }

    public String getDebitAmount() {
        return debitAmount;
    }

    public String getDate() {
        return date;
    }

    public String getCreditAmount() {
        return creditAmount;
    }

    public String getBalance() {
        return balance;
    }


}
